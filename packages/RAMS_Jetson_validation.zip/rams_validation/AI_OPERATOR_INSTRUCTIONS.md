# Operator instructions

Read `README.md` completely before making changes or running commands. Use real KITTI and COCO paths for a paper run, retain every manifest and raw record, and do not describe simulation smoke output as evidence.
