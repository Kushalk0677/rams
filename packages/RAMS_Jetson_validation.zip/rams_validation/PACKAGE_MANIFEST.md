# RAMS Jetson validation package

Scope: Jetson TensorRT validation with device-built engines.

Included: current RAMS source, tests, configuration, and operator documentation.

Excluded: datasets, model checkpoints, ONNX exports, TensorRT engines, virtual environments, and result records.
