# RAMS operator instructions

You are operating a reproducible evaluation package. Read `README.md` completely and execute its numbered sections in order. Work only inside the extracted package directory and never alter its source code, default configuration, models, or datasets unless the README explicitly directs it.

Before calibration, confirm Python, the requested inference backend, all three model tiers, the fixed KITTI replay, and COCO image and label paths. Run the documented smoke command and stop on any failure. A smoke run is not evidence.

For a full evaluation, create the device energy-profile input, run calibration once, preserve the resulting configuration, then run the phases in order. Retain the complete `results/` directory, including raw records, manifests, calibration snapshots, device state, and the energy profile. Do not report simulated results, proxy mAP, or estimated energy as measured physical energy.
