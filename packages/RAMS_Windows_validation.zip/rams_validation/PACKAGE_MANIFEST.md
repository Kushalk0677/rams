# RAMS Windows validation package

Scope: Windows CPU ONNX Runtime validation. NVIDIA hardware is telemetry-only.

Included: current RAMS source, tests, configuration, and operator documentation.

Excluded: datasets, model checkpoints, ONNX exports, TensorRT engines, virtual environments, and result records.
