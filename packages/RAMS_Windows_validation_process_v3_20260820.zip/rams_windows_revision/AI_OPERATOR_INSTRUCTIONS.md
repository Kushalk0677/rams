# RAMS Windows AI operator instructions

This document tells an autonomous AI how to prepare, validate, run, and hand
off the Windows RAMS package. It is an execution procedure, not a description
of the research claims.

The AI must run commands in PowerShell from the extracted package directory.
It may install Python packages, download public model and COCO files, create a
virtual environment, create a device-specific power profile, and write new
results under `results/`. It must not overwrite existing datasets, model files,
calibration snapshots, or completed result folders. It must stop and ask a
human if a required input is unavailable, ambiguous, or cannot be verified.

## 1. Required human-provided inputs

Before starting, obtain or verify all of the following. Do not guess paths.

| Input | Required for | Acceptance condition |
|---|---|---|
| Extracted package directory | Every step | Contains `setup.py`, `README.md`, `scripts/`, and `rams/` |
| Python 3.12.x | Every real run | `python --version` reports Python 3.12 |
| Device label | Results | A stable, human-readable identifier for the machine |
| KITTI 2D images and labels | Smoke, calibration, runtime, accuracy, retention | Fixed 1,500-image validation split is present |
| COCO val2017 images and YOLO labels | Smoke, runtime, accuracy, retention | 5,000 images are present; fewer labels are normal |
| Intended Windows power mode | Full run | Recorded before calibration and unchanged through the run |
| TDP/power-profile assumptions | Full runtime phases | Completed JSON copied from `configs/energy_profile.example.json` |

KITTI requires a human to register and download the source archives from the
KITTI website. An AI must not attempt to bypass registration, credentials, or
terms. It may prepare the split after the archives have been extracted.

## 2. Establish paths and inspect the package

Set paths once. The examples use `D:\data`; another location is acceptable if
the AI changes all variables consistently. Do not mix multiple KITTI or COCO
copies.

```powershell
cd <extracted-package-directory>

$env:PYTHONIOENCODING = "utf-8"
$env:RAMS_BACKEND = "onnx"
$PACKAGE = (Get-Location).Path
$DATA_ROOT = "D:\data"
$KITTI_IMAGES = Join-Path $DATA_ROOT "kitti\images\val"
$KITTI_LABELS = Join-Path $DATA_ROOT "kitti\labels\val"
$COCO_IMAGES = Join-Path $DATA_ROOT "coco\images\val2017"
$COCO_LABELS = Join-Path $DATA_ROOT "coco\labels\val2017"
$DEVICE = "<human-provided-device-label>"

Get-ChildItem setup.py,README.md,RAMS_Windows_Runbook.md,scripts,rams
```

Stop and ask a human if the package contents are missing or `$DEVICE` was not
provided.

Before downloading models or running a smoke, create the immutable device
inventory record. It captures every Windows display adapter, NVIDIA details
when `nvidia-smi` is available, CPU and memory, installed runtime packages,
ONNX providers, active Windows power plan, disk capacity, and the initial
configuration hash.

```powershell
python scripts\collect_device_info.py --device $DEVICE --data-root $DATA_ROOT
```

The command writes `results/device_inventory_<timestamp>_<device>.json`. The
AI must retain it unchanged and include it in the final handoff. It is an
inventory report only; its presence does not authorize GPU inference in this
CPU-ONNX Windows package.

## 3. Create the Python 3.12 environment

Use Python 3.12. Do not use an existing virtual environment from another
machine or project.

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install onnxruntime opencv-python matplotlib pynvml onnx onnxslim
pip install -e .
python -c "import cv2, onnxruntime, psutil, yaml; print(cv2.__version__); print(onnxruntime.__version__)"
python -c "from rams import RAMSController; print('RAMS import OK')"
```

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope CurrentUser
RemoteSigned`, then repeat activation. If the Python version is not 3.12, stop
and ask for the correct interpreter path. Do not silently run with another
Python version.

## 4. Obtain and verify the three model tiers

The package intentionally does not contain model files. Download the official
YOLOv8 checkpoints and export the exact ONNX files used by the runtime.

```powershell
python -c "from ultralytics import YOLO; [YOLO(name) for name in ('yolov8n.pt', 'yolov8s.pt', 'yolov8m.pt')]"
python -c "from ultralytics import YOLO; YOLO('yolov8n.pt').export(format='onnx', imgsz=320, opset=12); YOLO('yolov8s.pt').export(format='onnx', imgsz=416, opset=12); YOLO('yolov8m.pt').export(format='onnx', imgsz=640, opset=12)"
Get-ChildItem yolov8n.pt,yolov8s.pt,yolov8m.pt,yolov8n.onnx,yolov8s.onnx,yolov8m.onnx | Select-Object Name,Length
Get-FileHash yolov8n.pt,yolov8s.pt,yolov8m.pt,yolov8n.onnx,yolov8s.onnx,yolov8m.onnx -Algorithm SHA256
```

The package pins Ultralytics 8.4.92 in `requirements.txt`. Record the model
hashes and the installed execution stack before starting the smoke:

```powershell
python -c "import ultralytics, torch, onnxruntime; print('ultralytics=', ultralytics.__version__); print('torch=', torch.__version__); print('onnxruntime=', onnxruntime.__version__); print('providers=', onnxruntime.get_available_providers())"
```

Stop if any of the six model files is missing or zero bytes, or if the
Ultralytics version is not 8.4.92. Windows evaluation uses ONNX Runtime CPU.

## 5. Download, prepare, and validate datasets

### 5.1 KITTI 2D Object Detection

KITTI images and labels require free registration at the
[KITTI 2D Object Detection page](https://www.cvlibs.net/datasets/kitti/eval_object.php?obj_benchmark=2d).
The human must download the following archives and tell the AI where they were
saved:

- `data_object_image_2.zip`
- `data_object_label_2.zip`

The AI must not attempt to register an account, bypass access controls, or use
an unverified mirror. After the human provides the two archive paths, extract
them without modifying `kitti_raw` or any existing KITTI copy:

If both `$KITTI_IMAGES` and `$KITTI_LABELS` already exist, skip the KITTI
download, extraction, and split-creation commands in this section. Validate
the existing split in Section 5.3 and reuse it only if both counts are 1,500.
If only one of those directories exists, stop and ask a human to resolve the
incomplete prior setup.

```powershell
$KITTI_IMAGE_ZIP = "<human-provided-path>\data_object_image_2.zip"
$KITTI_LABEL_ZIP = "<human-provided-path>\data_object_label_2.zip"
$KITTI_ROOT = Join-Path $DATA_ROOT "kitti"
$KITTI_SOURCE_IMAGES = Join-Path $KITTI_ROOT "training\image_2"
$KITTI_SOURCE_LABELS = Join-Path $KITTI_ROOT "training\label_2"

if (!(Test-Path -LiteralPath $KITTI_IMAGE_ZIP)) { throw "KITTI image archive is missing" }
if (!(Test-Path -LiteralPath $KITTI_LABEL_ZIP)) { throw "KITTI label archive is missing" }
if (!(Test-Path -LiteralPath $KITTI_SOURCE_IMAGES) -or !(Test-Path -LiteralPath $KITTI_SOURCE_LABELS)) {
  if (Test-Path -LiteralPath $KITTI_ROOT) { throw "Refusing to extract KITTI into an existing incomplete tree" }
  New-Item -ItemType Directory -Force -Path $KITTI_ROOT | Out-Null
  Expand-Archive -LiteralPath $KITTI_IMAGE_ZIP -DestinationPath $KITTI_ROOT
  Expand-Archive -LiteralPath $KITTI_LABEL_ZIP -DestinationPath $KITTI_ROOT
}

if (!(Test-Path -LiteralPath $KITTI_SOURCE_IMAGES)) { throw "KITTI image extraction layout is unexpected" }
if (!(Test-Path -LiteralPath $KITTI_SOURCE_LABELS)) { throw "KITTI label extraction layout is unexpected" }
```

Create the fixed 1,500-frame validation split from sorted training frames 5981
through 7480. This split must be used unchanged on every device:

```powershell
$KITTI_IMAGES = Join-Path $KITTI_ROOT "images\val"
$KITTI_LABELS = Join-Path $KITTI_ROOT "labels\val"
if ((Test-Path -LiteralPath $KITTI_IMAGES) -or (Test-Path -LiteralPath $KITTI_LABELS)) {
  throw "Refusing to overwrite an existing KITTI validation split"
}
New-Item -ItemType Directory -Force -Path $KITTI_IMAGES,$KITTI_LABELS | Out-Null

$images = Get-ChildItem -LiteralPath $KITTI_SOURCE_IMAGES -Filter *.png | Sort-Object Name
$labels = Get-ChildItem -LiteralPath $KITTI_SOURCE_LABELS -Filter *.txt | Sort-Object Name
if ($images.Count -lt 7481 -or $labels.Count -lt 7481) { throw "KITTI source extraction is incomplete" }
$images[5981..7480] | Copy-Item -Destination $KITTI_IMAGES
$labels[5981..7480] | Copy-Item -Destination $KITTI_LABELS
```

### 5.2 COCO val2017 and YOLO labels

COCO val2017 images and the Ultralytics YOLO labels are public downloads. The
AI may download them after confirming that the destination is the intended
data root and neither archive already exists. Do not download a second copy if
the files are already present.

```powershell
$COCO_ROOT = Join-Path $DATA_ROOT "coco"
$COCO_IMAGES = Join-Path $COCO_ROOT "images\val2017"
$COCO_LABELS = Join-Path $COCO_ROOT "labels\val2017"
$COCO_IMAGE_ZIP = Join-Path $COCO_ROOT "val2017.zip"
$COCO_LABEL_ZIP = Join-Path $COCO_ROOT "coco2017labels.zip"
New-Item -ItemType Directory -Force -Path $COCO_ROOT | Out-Null

if (!(Test-Path -LiteralPath $COCO_IMAGES)) {
  if (!(Test-Path -LiteralPath $COCO_IMAGE_ZIP)) {
    Invoke-WebRequest -Uri "http://images.cocodataset.org/zips/val2017.zip" -OutFile $COCO_IMAGE_ZIP
  }
  Expand-Archive -LiteralPath $COCO_IMAGE_ZIP -DestinationPath $COCO_ROOT
}
if (!(Test-Path -LiteralPath $COCO_LABELS)) {
  if (!(Test-Path -LiteralPath $COCO_LABEL_ZIP)) {
    Invoke-WebRequest -Uri "https://github.com/ultralytics/assets/releases/download/v0.0.0/coco2017labels.zip" -OutFile $COCO_LABEL_ZIP
  }
  Expand-Archive -LiteralPath $COCO_LABEL_ZIP -DestinationPath $COCO_ROOT
}
```

If an expected archive or directory already exists, inspect it and reuse it
only if it passes the checks below. Do not overwrite it. The mandatory final
layouts are:

```text
<data-root>\kitti\images\val\000000.png
<data-root>\kitti\labels\val\000000.txt
<data-root>\coco\images\val2017\000000000139.jpg
<data-root>\coco\labels\val2017\000000000139.txt
```

Run these checks before any smoke or paper phase:

```powershell
(Get-ChildItem -LiteralPath $KITTI_IMAGES -Filter *.png).Count
(Get-ChildItem -LiteralPath $KITTI_LABELS -Filter *.txt).Count
(Get-ChildItem -LiteralPath $COCO_IMAGES -File).Count
$cocoLabelCount = (Get-ChildItem -LiteralPath $COCO_LABELS -Filter *.txt).Count
$cocoLabelCount
```

KITTI image and label counts must both be 1,500. COCO must contain 5,000
images. COCO label-file count can be lower because unannotated images have no
label file, but it must be greater than zero. Stop if the validation split is
incomplete or paths refer to `kitti_raw`; that is a different dataset and must
not be overwritten.

## 6. Create the device power profile

This is a telemetry/TDP estimate, not a physical power measurement. The AI
must not call it measured energy.

```powershell
Copy-Item configs\energy_profile.example.json configs\energy_profile_windows.json
Get-Content configs\energy_profile_windows.json
```

The human must provide or approve the profile assumptions, including the
device, TDP value, source, and Windows power mode. The AI may write those
human-approved values into `configs\energy_profile_windows.json`; it must not
invent them. Stop before a full runtime run if this file is absent or still
contains placeholder values.

## 7. Preflight and smoke gate

Do not begin a paper run before this command exits with code zero. It performs
real ONNX inference but uses short blocks and capped accuracy checks. Smoke
results are setup evidence only and must not be cited as paper results.

```powershell
python scripts\run_paper_suite.py --platform windows --smoke --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS `
  --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS
```

Inspect the generated `results/paper_all_*.json` manifest. The `preflight`
entry must have `"ok": true`, `"smoke": true`, and `"simulated": false`.
Every entry in that manifest must have `"ok": true`; child-stage entries do not
repeat the smoke and simulation fields. Runtime summaries must list only
`"onnx"` under `backends`. A capped COCO smoke uses cached mAP fields by
design. It does not substitute for full COCO mAP.

If a smoke fails, preserve its manifest and logs, report the failing command
and traceback to the human, fix only the documented setup issue, and rerun the
smoke. Do not edit source code or change thresholds to make a smoke pass unless
the human explicitly authorizes a code change.

## 8. Calibration gate

Connect laptops to power, select the intended power mode, close unrelated
workloads, and record cooling conditions. Calibration uses real fixed-SMALL
KITTI replay under the steady load profiles. This package uses
`process_steady_v3`: independent worker processes occupy all but one logical
CPU, with a duty cycle scaled to the requested whole-host load. It saves the
previous YAML before writing a device-specific threshold pair.

```powershell
# Diagnostic only. Do this before calibration and retain its console output.
python scripts\verify_process_load.py --intensity 0.75 --settle-s 3 --samples 8

python scripts\run_paper_suite.py --phase calibration --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES
```

The diagnostic must report seven workers on an eight-logical-core machine or
15 workers on a 16-logical-core machine when one controller CPU is reserved.
It must report substantial nonzero CPU use. It is not an acceptance test for
an exact percentage: Windows scheduling and other services vary the measured
host value. The accepted calibration report remains the required gate.

Accept calibration only if the generated `results/calibration_*.json` states
`"applied": true` and `"load_injector": "process_steady_v3"`. Preserve the calibration report and both YAML snapshots in
`results/calibration_snapshots/`. Keep the resulting `configs/default.yaml`
unchanged for Phases 2a through 4. If calibration is rejected for insufficient
pressure separation, stop and report the measured profile statistics. Do not
manually choose thresholds.

Do not continue from, merge with, or report any Windows runtime result made
under `thread_steady_v1`. That archived GIL-bound thread injector cannot reach
the declared host-level targets on many-core Windows computers. Start again
with this accepted calibration and complete Phases 2a through 2d under
`process_steady_v3`.

## 9. Run the paper workflow in order

Use the same `$DEVICE`, model files, dataset copies, Windows power mode,
cooling condition, and calibrated YAML for every phase. A failed phase must be
resolved before the next phase starts. Do not combine results created before a
fresh accepted calibration with results created after it.

```powershell
# Phase 2a: idle and light paired replay
python scripts\run_paper_suite.py --phase runtime1 --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS `
  --energy-profile configs\energy_profile_windows.json

# Phase 2b: moderate replay and fixed-tier Pareto
python scripts\run_paper_suite.py --phase runtime2 --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS `
  --energy-profile configs\energy_profile_windows.json

# Phase 2c: heavy replay and fixed-tier Pareto
python scripts\run_paper_suite.py --phase runtime3 --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS `
  --energy-profile configs\energy_profile_windows.json

# Phase 2d: process-isolated transient burst replay
python scripts\run_paper_suite.py --phase runtime4 --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS `
  --energy-profile configs\energy_profile_windows.json `
  --burst-peak-intensity 0.85 --burst-on-frames 20 --burst-off-frames 80 `
  --burst-settle-s 0.20 --load-reserve-logical-cpus 1

# Phase 3: full KITTI policy metrics and measured full COCO mAP
python scripts\run_paper_suite.py --phase accuracy --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS

# Phase 4: VRU-retention sensitivity and sustained-VRU analysis
python scripts\run_paper_suite.py --phase retention --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS
```

`python scripts\run_paper_suite.py` without `--phase` runs the full workflow,
but phased execution is preferred for unattended operation because each phase
has a separate manifest and review gate.

## 10. Phase acceptance checks

After every phase, inspect its `results/paper_<phase>_*.json` manifest. The AI
must report and stop if any entry has `"ok": false`, a nonzero return code,
`"simulated": true`, or a backend other than `onnx` for Windows runtime data.

For the full Phase 3 result, inspect `results/exp8_accuracy_coco.json`. Every
tier must report `"map_source": "ultralytics_val"`. If it reports
`"cached_profile"`, the COCO result is not a measured mAP result and Phase 3
must be rerun after resolving the Ultralytics validation issue.

For runtime evidence, require all of the following:

- 10 blocks and 200 frames per method/profile/block in each full runtime phase.
- Raw `rams_*.csv`, summary `rams_*.json`, and replay manifest files.
- The recorded load protocol: `process_steady_v3` for idle, light, moderate,
  and heavy, and `process_isolated_burst_v2` for burst. The calibration report
  and every runtime manifest must name those protocols.
- Block-bootstrap 95% confidence intervals in summary records.

For energy, report only the stated telemetry/TDP estimate. Do not claim a
physical meter reading, battery life, or measured energy consumption.

## 11. Handoff contents

When all phases pass, preserve the entire `results/` directory. Do not send
only charts or aggregate tables. The AI handoff must include:

- Device label, OS, Python, Ultralytics, ONNX Runtime, and provider versions.
- Model filenames, SHA-256 hashes, resolutions, and checkpoints.
- Data-root paths and a statement that the KITTI validation split contains
  1,500 images and COCO val2017 contains 5,000 images.
- Windows power mode, cooling condition, energy-profile source, and the
  calibration report plus configuration snapshots.
- Every phase manifest, raw CSV, JSON summary, replay manifest, and plot.
- A short list of failures, reruns, and deviations. If none occurred, state
  that explicitly.

Never overwrite or merge `results/` from different devices. Place each device
handoff in a separately named directory before transferring it.

## 12. Prohibited shortcuts

- Do not use `--simulate` for paper evidence.
- Do not call a smoke result a paper result.
- Do not replace a failed full COCO mAP run with cached mAP fields.
- Do not silently fall back from ONNX to PyTorch or simulation.
- Do not alter the calibrated YAML between runtime and accuracy phases.
- Do not overwrite `kitti_raw`, datasets, calibration snapshots, or prior
  device results.
- Do not claim that VRU retention is a safety guarantee or that it recovers
  initially missed VRUs.
