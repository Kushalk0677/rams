# RAMS Windows Package

This package runs RAMS on Windows with ONNX Runtime.

Windows steady-load evidence uses the cross-core `process_steady_v3` protocol.
It supersedes the archived GIL-bound `thread_steady_v1` protocol. Operators
must run a fresh accepted calibration and all four runtime phases with this
package; results from the two protocols must not be combined.

Included:

- RAMS source, benchmark, experiments, tests, scripts, and configuration.
- Windows setup instructions in `README.md`.
- Windows operational instructions in `RAMS_Windows_Runbook.md`.
- Autonomous execution instructions in `AI_OPERATOR_INSTRUCTIONS.md`.
- The energy-profile template.

Not included:

- Datasets, results, virtual environments, model weights, and ONNX exports.
- TensorRT engines, which are not used by this package.

Follow `README.md` for installation, model preparation, and dataset download.
Run `RAMS_Windows_Runbook.md` after setup for the smoke check and full phased
evaluation.
