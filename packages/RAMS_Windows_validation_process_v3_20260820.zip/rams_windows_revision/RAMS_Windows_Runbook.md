# RAMS Windows Runbook

This is the complete operational guide for running RAMS on Windows with ONNX
Runtime. Run every command from the extracted package directory.

An autonomous AI must follow [AI_OPERATOR_INSTRUCTIONS.md](AI_OPERATOR_INSTRUCTIONS.md)
before executing this runbook. In particular, it must not invent dataset paths,
substitute simulated output for a real run, or overwrite existing evidence.

## 1. Before you begin

| Requirement | Minimum guidance |
|---|---|
| Python | Version 3.12.x |
| Storage | About 25 GB free for KITTI, COCO, models, and results |
| Memory | 16 GB recommended |
| Power | Keep a laptop plugged in and use the intended Windows power mode |
| Datasets | KITTI 2D object detection and COCO val2017 |

If Windows blocks PowerShell activation scripts, run once:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

Extract the package, then enter the extracted directory:

```powershell
$archive = Join-Path $HOME "Downloads\RAMS_Windows_validation_20260820.zip"
Expand-Archive -LiteralPath $archive -DestinationPath C:\rams\rams_windows_revision
cd C:\rams\rams_windows_revision
```

## 2. Create the Python environment

```powershell
python --version  # must report Python 3.12.x
python -m venv .venv
.\.venv\Scripts\Activate.ps1
$env:PYTHONIOENCODING = "utf-8"
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install onnxruntime opencv-python matplotlib pynvml onnx onnxslim
pip install -e .
```

Verify the environment:

```powershell
python -c "import cv2, onnxruntime, psutil, yaml; print('OpenCV', cv2.__version__); print('ONNX Runtime', onnxruntime.__version__)"
python -c "from rams import RAMSController; print('RAMS import OK')"
```

This package enforces ONNX Runtime CPU inference on Windows. Do not substitute
`onnxruntime-gpu`, PyTorch, TensorRT, or simulation for the documented runs.

## 3. Download weights and export ONNX models

The full run needs NANO at 320, SMALL at 416, and MEDIUM at 640. Download the
official YOLOv8 checkpoints and export them in this package directory:

```powershell
python -c "from ultralytics import YOLO; [YOLO(name) for name in ('yolov8n.pt', 'yolov8s.pt', 'yolov8m.pt')]"
python -c "from ultralytics import YOLO; YOLO('yolov8n.pt').export(format='onnx', imgsz=320, opset=12); YOLO('yolov8s.pt').export(format='onnx', imgsz=416, opset=12); YOLO('yolov8m.pt').export(format='onnx', imgsz=640, opset=12)"
Get-ChildItem yolov8n.pt,yolov8s.pt,yolov8m.pt,yolov8n.onnx,yolov8s.onnx,yolov8m.onnx
```

All six files must be present before a real run.

## 4. Download and prepare KITTI

Register for free at the [KITTI 2D Object Detection page](https://www.cvlibs.net/datasets/kitti/eval_object.php?obj_benchmark=2d).
Download the left-color training images and training labels, normally named
`data_object_image_2.zip` and `data_object_label_2.zip`.

Extract them to this layout:

```text
C:\rams\data\kitti\images\training\image_2\
C:\rams\data\kitti\labels\training\label_2\
```

Create the fixed 1,500-image validation split. Use this same split on every
device.

```powershell
$imageSource = 'C:\rams\data\kitti\images\training\image_2'
$labelSource = 'C:\rams\data\kitti\labels\training\label_2'
$imageVal = 'C:\rams\data\kitti\images\val'
$labelVal = 'C:\rams\data\kitti\labels\val'
if ((Test-Path -LiteralPath $imageVal) -or (Test-Path -LiteralPath $labelVal)) {
  throw "Refusing to overwrite an existing KITTI validation split"
}
New-Item -ItemType Directory -Force -Path $imageVal, $labelVal | Out-Null

$images = Get-ChildItem -LiteralPath $imageSource -Filter *.png | Sort-Object Name
$labels = Get-ChildItem -LiteralPath $labelSource -Filter *.txt | Sort-Object Name
if ($images.Count -lt 7481 -or $labels.Count -lt 7481) { throw "KITTI source extraction is incomplete" }
$images[5981..7480] | Copy-Item -Destination $imageVal
$labels[5981..7480] | Copy-Item -Destination $labelVal

(Get-ChildItem -LiteralPath $imageVal -Filter *.png).Count
(Get-ChildItem -LiteralPath $labelVal -Filter *.txt).Count
```

Both counts must be 1500. If the split already exists, validate those counts
and reuse it without recreating it.

## 5. Download and prepare COCO val2017

Download the COCO validation images and Ultralytics YOLO labels:

```powershell
New-Item -ItemType Directory -Force -Path C:\rams\data\coco | Out-Null
Invoke-WebRequest -Uri "http://images.cocodataset.org/zips/val2017.zip" -OutFile C:\rams\data\coco\val2017.zip
Expand-Archive C:\rams\data\coco\val2017.zip -DestinationPath C:\rams\data\coco
Invoke-WebRequest -Uri "https://github.com/ultralytics/assets/releases/download/v0.0.0/coco2017labels.zip" -OutFile C:\rams\data\coco\coco2017labels.zip
Expand-Archive C:\rams\data\coco\coco2017labels.zip -DestinationPath C:\rams\data\coco
```

Expected layout:

```text
C:\rams\data\coco\images\val2017\
C:\rams\data\coco\labels\val2017\
```

There must be 5,000 images. Fewer label files are normal because some COCO
images contain no annotated objects.

## 6. Create the device power profile

This profile supports a telemetry-based energy estimate. It is not a physical
power measurement.

```powershell
Copy-Item configs\energy_profile.example.json configs\energy_profile_windows.json
notepad configs\energy_profile_windows.json
```

Document the device and Windows power mode in the profile's `source` field.

## 7. Set paths and run a smoke check

```powershell
$env:RAMS_BACKEND = "onnx"
$KITTI_IMAGES = "C:\rams\data\kitti\images\val"
$KITTI_LABELS = "C:\rams\data\kitti\labels\val"
$COCO_IMAGES = "C:\rams\data\coco\images\val2017"
$COCO_LABELS = "C:\rams\data\coco\labels\val2017"
$DEVICE = "<machine-label>"

python scripts\collect_device_info.py --device $DEVICE --data-root C:\rams\data

# Diagnostic only. Run before calibration, retain the console output, and do
# not treat it as paper evidence.
python scripts\verify_process_load.py --intensity 0.75 --settle-s 3 --samples 8

python scripts\run_paper_suite.py --platform windows --smoke --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS `
  --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS
```

The smoke run uses real inference but is only a setup check. Resolve every
error before starting the full workflow.

## 8. Run the full workflow in phases

Keep the Windows power mode, cooling condition, model files, and
`configs/default.yaml` unchanged after calibration. Each command writes a
manifest in `results/`; inspect it before proceeding.

This package uses `process_steady_v3` for idle, light, moderate, and heavy
profiles. It uses independent processes on all but one logical CPU and records
the measured CPU and pressure values alongside each requested load target. Do
not mix results produced by the archived `thread_steady_v1` protocol with this
workflow. Complete a new accepted calibration before any runtime phase.

```powershell
# Phase 1: replay calibration. It needs KITTI images, but not COCO.
python scripts\run_paper_suite.py --phase calibration --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES

# Phase 2a: idle and light runtime replay
python scripts\run_paper_suite.py --phase runtime1 --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS `
  --energy-profile configs\energy_profile_windows.json

# Phase 2b: moderate runtime replay and Pareto sweep
python scripts\run_paper_suite.py --phase runtime2 --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS `
  --energy-profile configs\energy_profile_windows.json

# Phase 2c: heavy runtime replay and Pareto sweep
python scripts\run_paper_suite.py --phase runtime3 --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS `
  --energy-profile configs\energy_profile_windows.json

# Phase 2d: burst runtime replay
python scripts\run_paper_suite.py --phase runtime4 --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS `
  --energy-profile configs\energy_profile_windows.json

# Phase 3: KITTI policy accuracy and COCO tier validation
python scripts\run_paper_suite.py --phase accuracy --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS

# Phase 4: retention sensitivity at confidence 0.25 and 0.40
python scripts\run_paper_suite.py --phase retention --platform windows --device $DEVICE `
  --frames $KITTI_IMAGES --kitti-labels $KITTI_LABELS --coco-images $COCO_IMAGES --coco-labels $COCO_LABELS
```

To run burst replay and the accuracy phase back to back, use
`scripts\run_phase2d_then_phase3.py`; see `README.md` for its full command.

## 9. Check and hand off results

Keep the entire `results/` directory. Required outputs include:

- `device_inventory_*.json` for the OS, CPU, memory, GPU, driver, provider,
  power-plan, package-version, and disk-space record captured before smoke.
- `rams_*.csv`, `rams_*.json`, and `rams_*_manifest.json` for runtime data.
- `exp5_pareto_*` for fixed-tier Pareto results.
- `exp8_*` for KITTI and COCO tier validation.
- `exp11_policy_accuracy_*` for policy-level KITTI metrics.
- `exp12_retention_sensitivity_*` for retention sensitivity.
- `paper_*.json` for phase manifests.

For a full COCO result, every tier in `exp8_accuracy_coco.json` must record
`"map_source": "ultralytics_val"`. Runtime summaries must report only
`"onnx"` in their `backends` field.

## 10. Troubleshooting

- If `Activate.ps1` is blocked, use the execution-policy command in Section 1.
- If `cv2` or `matplotlib` is missing, rerun the installation commands in
  Section 2.
- If an ONNX model is missing, rerun Section 3. The configured ONNX backend
  fails rather than silently switching backends.
- If a COCO run does not report `ultralytics_val`, install `ultralytics` in the
  active environment and rerun the full COCO validation.
- If a laptop becomes slow or throttles, connect power, select the intended
  Windows power mode, close background applications, and recalibrate before
  starting the phased run again.
