# RAMS Windows package: full setup and paper run

This package runs the RAMS evaluation on Windows using ONNX Runtime. It is for
runtime, resource-telemetry, and detection-policy evaluation. It does not
measure board energy, simulate vehicle dynamics, or establish a safety claim.

For an autonomous AI or agent carrying out the setup and measurement work, use
[AI_OPERATOR_INSTRUCTIONS.md](AI_OPERATOR_INSTRUCTIONS.md) first. It defines
the required inputs, commands, validation gates, stop conditions, and handoff
artifacts. This README remains the human-readable setup reference.

## Included and not included

Included in this package:

- RAMS source, benchmark, experiments, tests, and the paper-run script.
- Default configuration and an energy-profile template.

Not included:

- KITTI and COCO images and labels.
- YOLOv8 model weights and exported ONNX models.
- A completed device power-profile JSON file.
- Python, drivers, virtual environment, or results.
- TensorRT engines. They are not used by this Windows ONNX package.

## 1. Install Python dependencies

Use Python 3.12.x. Run these commands from the extracted package directory,
where `setup.py` is visible. The ONNX files are created in Section 2.

```powershell
python --version  # must report Python 3.12.x
python -m venv .venv
.\.venv\Scripts\Activate.ps1
$env:PYTHONIOENCODING = "utf-8"
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install onnxruntime opencv-python matplotlib pynvml
pip install -e .
```

This package requires the ONNX Runtime CPU execution provider. Installing
`onnxruntime-gpu` does not make this Windows protocol a GPU experiment.
`pynvml` is optional and only enables NVIDIA telemetry when NVML is available.

Check the environment before downloading data:

```powershell
python -c "import cv2, onnxruntime, psutil, yaml; print('OpenCV', cv2.__version__); print('ONNX Runtime', onnxruntime.__version__)"
python -c "from rams import RAMSController; print('RAMS import OK')"
```

Keep the `PYTHONIOENCODING` setting in the PowerShell session for every smoke,
calibration, and paper-run command below. It ensures the calibration report
works on Windows consoles that otherwise default to a legacy code page.

## 2. Download weights and export the ONNX models

The runner uses three YOLOv8 tiers at fixed resolutions: NANO at 320, SMALL at
416, and MEDIUM at 640. Download the official Ultralytics weights into this
package directory, then export the ONNX models from those exact weights.

```powershell
python -c "from ultralytics import YOLO; [YOLO(name) for name in ('yolov8n.pt', 'yolov8s.pt', 'yolov8m.pt')]"
pip install onnx onnxslim
python -c "from ultralytics import YOLO; YOLO('yolov8n.pt').export(format='onnx', imgsz=320, opset=12); YOLO('yolov8s.pt').export(format='onnx', imgsz=416, opset=12); YOLO('yolov8m.pt').export(format='onnx', imgsz=640, opset=12)"
```

Confirm that all six files are in the package directory before continuing:

```powershell
Get-ChildItem yolov8n.pt,yolov8s.pt,yolov8m.pt,yolov8n.onnx,yolov8s.onnx,yolov8m.onnx
```

RAMS prefers ONNX Runtime when the `.onnx` file is present. The `.pt` files are
kept so that the ONNX models can be recreated from the same checkpoints.

## 3. Obtain and prepare KITTI and COCO

Paper runs require labelled KITTI 2D object-detection frames. Register at the
KITTI 2D Object Detection page, download the left-color training images and
training labels, then extract them. The two downloaded archives are normally
named `data_object_image_2.zip` and `data_object_label_2.zip`.

Keep the original extraction, then create the fixed 1,500-frame validation
split used by RAMS. The commands below select sorted training frames 5981
through 7480, matching the existing project convention.

```powershell
# Expected extracted directories before making the split:
# C:\rams\data\kitti\images\training\image_2\
# C:\rams\data\kitti\labels\training\label_2\

$imageSource = 'C:\rams\data\kitti\images\training\image_2'
$labelSource = 'C:\rams\data\kitti\labels\training\label_2'
$imageVal = 'C:\rams\data\kitti\images\val'
$labelVal = 'C:\rams\data\kitti\labels\val'
if ((Test-Path -LiteralPath $imageVal) -or (Test-Path -LiteralPath $labelVal)) {
  throw "Refusing to overwrite an existing KITTI validation split"
}
New-Item -ItemType Directory -Force -Path $imageVal, $labelVal | Out-Null

$images = Get-ChildItem -LiteralPath $imageSource -Filter *.png | Sort-Object Name
$labels = Get-ChildItem -LiteralPath $labelSource -Filter *.txt | Sort-Object Name
if ($images.Count -lt 7481 -or $labels.Count -lt 7481) { throw "KITTI source extraction is incomplete" }
$images[5981..7480] | Copy-Item -Destination $imageVal
$labels[5981..7480] | Copy-Item -Destination $labelVal

(Get-ChildItem -LiteralPath $imageVal -Filter *.png).Count
(Get-ChildItem -LiteralPath $labelVal -Filter *.txt).Count
```

Both counts must be 1500. If the split already exists, validate those counts
and reuse it without recreating it. Use the same split on every evaluated
device. The runner expects this layout:

```text
C:\rams\data\kitti\images\val\000000.png
C:\rams\data\kitti\labels\val\000000.txt
```

The full runner also requires COCO val2017 images and YOLO-format labels. Put
them in these directories:

```text
C:\rams\data\coco\images\val2017\000000000139.jpg
C:\rams\data\coco\labels\val2017\000000000139.txt
```

Download the COCO val2017 images and the Ultralytics COCO labels, then extract
them under `C:\rams\data\coco`. The image archive is available from the COCO
download site as `val2017.zip`; the label archive is `coco2017labels.zip` from
the Ultralytics assets release. Some COCO images have no objects and therefore
no label file, so 5,000 images and fewer than 5,000 label files is expected.

## 4. Create the device power profile

The package estimates energy from runtime telemetry. It does not use a power
meter. Copy the template, then replace every sample value and the `source`
field with values tied to this machine and its documented power mode.

```powershell
Copy-Item configs\energy_profile.example.json configs\energy_profile_windows.json
notepad configs\energy_profile_windows.json
```

Use the profile only for the claim: "estimated energy under the stated
telemetry-conditioned power model." Do not call the resulting joules measured
energy.

## 5. Smoke run

Before the smoke, write the device inventory report and retain it with the
results handoff:

```powershell
python scripts\collect_device_info.py --device <machine-label> --data-root C:\rams\data

# Diagnostic only. Confirms that the cross-core steady loader produces
# substantial measured host CPU use before calibration.
python scripts\verify_process_load.py --intensity 0.75 --settle-s 3 --samples 8
```

Retain the diagnostic console output with the setup notes. It is not paper
evidence and it does not replace calibration. It should show one worker per
available logical CPU except the reserved controller CPU, with a substantial
nonzero measured CPU level. Do not require the measured value to equal the
requested target exactly; Windows scheduling and background services affect
that value. Calibration uses the measured pressure separation as its gate.

Run this after the checks above. It uses real inference, one five-frame replay
block, and 20 labelled images. It confirms paths, models, and outputs. It is
not publishable evidence.

```powershell
python scripts\run_paper_suite.py --platform windows --smoke `
  --device <machine-label> `
  --frames C:\rams\data\kitti\images\val `
  --kitti-labels C:\rams\data\kitti\labels\val `
  --coco-images C:\rams\data\coco\images\val2017 `
  --coco-labels C:\rams\data\coco\labels\val2017
```

## 6. Full paper run

This is the default mode. It runs 10 paired replay blocks of 200 frames per
policy and load condition, calibrates the local resource thresholds, evaluates
fixed tiers and policies, controller-level KITTI metrics, and supplementary
COCO tier-level metrics. It can take many hours.

The Windows runner enforces `--backend onnx`. If an ONNX model or ONNX Runtime
is missing, the run fails instead of silently changing backend. Confirm that
every runtime JSON summary reports only `"onnx"` in its `backends` field.

```powershell
python scripts\run_paper_suite.py --platform windows `
  --device <machine-label> `
  --frames C:\rams\data\kitti\images\val `
  --kitti-labels C:\rams\data\kitti\labels\val `
  --coco-images C:\rams\data\coco\images\val2017 `
  --coco-labels C:\rams\data\coco\labels\val2017 `
  --energy-profile configs\energy_profile_windows.json
```

The runner writes a manifest in `results/paper_all_*.json`. Treat a
full run as usable only when that manifest has no failed stage and reports
`smoke: false` and `simulated: false`.

## Run the full workflow in phases

Use phases when the computer cannot remain available for a full day. Each phase
writes its own manifest. Run calibration first, then runtime1 through runtime4,
then accuracy.
The calibration phase saves the existing `configs/default.yaml` before applying
new thresholds and saves the applied configuration afterwards in
`results/calibration_snapshots/`.

Use the following steps in order on every device and backend:

All steady runtime profiles in this package use `process_steady_v3`. It starts
independent worker processes across all but one logical CPU and scales their
duty cycle to the requested whole-host target. The reserved CPU keeps the
controller schedulable. Idle starts no workers. The raw records contain the
requested target and measured CPU/pressure telemetry; measured telemetry, not
the target, is the evidence of achieved load.

Do not combine any Windows result created with the older
`thread_steady_v1` protocol with results from this package. Re-run calibration
and all four runtime phases under `process_steady_v3`. Phase 2d additionally
uses `process_isolated_burst_v2`: 20 frames at a requested 0.85 host load,
then 80 recovery frames, repeated within each block.

1. Finish Sections 1 through 4, including the model, dataset, and power-profile
   checks.
2. Run the smoke command in Section 5 and resolve every error.
3. Run Phase 1 once, then keep the resulting `configs/default.yaml` unchanged
   for Phases 2a through 4 on that device/backend.
4. Run Phases 2a, 2b, 2c, 2d, Phase 3, and Phase 4 below. Check each
   `results/paper_<phase>_*.json` manifest before starting the next phase.
5. Preserve the complete `results/` directory, including raw CSV files and
   manifests. Do not copy only summary tables.

```powershell
# Phase 1: replay calibration only. It needs KITTI images, but not COCO.
python scripts\run_paper_suite.py --phase calibration --platform windows --device <machine-label> `
  --frames C:\rams\data\kitti\images\val

# Phase 2a: idle and light paired runtime replay
python scripts\run_paper_suite.py --phase runtime1 --platform windows --device <machine-label> `
  --frames C:\rams\data\kitti\images\val `
  --kitti-labels C:\rams\data\kitti\labels\val `
  --coco-images C:\rams\data\coco\images\val2017 `
  --coco-labels C:\rams\data\coco\labels\val2017 `
  --energy-profile configs\energy_profile_windows.json

# Phase 2b: moderate replay plus moderate fixed-tier Pareto
python scripts\run_paper_suite.py --phase runtime2 --platform windows --device <machine-label> `
  --frames C:\rams\data\kitti\images\val `
  --kitti-labels C:\rams\data\kitti\labels\val `
  --coco-images C:\rams\data\coco\images\val2017 `
  --coco-labels C:\rams\data\coco\labels\val2017 `
  --energy-profile configs\energy_profile_windows.json

# Phase 2c: heavy replay plus heavy fixed-tier Pareto
python scripts\run_paper_suite.py --phase runtime3 --platform windows --device <machine-label> `
  --frames C:\rams\data\kitti\images\val `
  --kitti-labels C:\rams\data\kitti\labels\val `
  --coco-images C:\rams\data\coco\images\val2017 `
  --coco-labels C:\rams\data\coco\labels\val2017 `
  --energy-profile configs\energy_profile_windows.json

# Phase 2d: transient burst replay. Defaults are 0.85 for 20 on-frames and
# 80 recovery frames. Keep these values unless they are changed for every device.
python scripts\run_paper_suite.py --phase runtime4 --platform windows --device <machine-label> `
  --frames C:\rams\data\kitti\images\val `
  --kitti-labels C:\rams\data\kitti\labels\val `
  --coco-images C:\rams\data\coco\images\val2017 `
  --coco-labels C:\rams\data\coco\labels\val2017 `
  --energy-profile configs\energy_profile_windows.json `
  --burst-peak-intensity 0.85 --burst-on-frames 20 --burst-off-frames 80 `
  --burst-settle-s 0.20 --load-reserve-logical-cpus 1

# Phase 3: full KITTI and COCO accuracy evaluation
# Use the venv because this phase requires Ultralytics for measured COCO mAP.
.\.venv\Scripts\python.exe scripts\run_paper_suite.py --phase accuracy --platform windows --device <machine-label> `
  --frames C:\rams\data\kitti\images\val `
  --kitti-labels C:\rams\data\kitti\labels\val `
  --coco-images C:\rams\data\coco\images\val2017 `
  --coco-labels C:\rams\data\coco\labels\val2017

# Phase 4: real KITTI VRU-retention sensitivity and sustained-VRU analysis
.\.venv\Scripts\python.exe scripts\run_paper_suite.py --phase retention --platform windows --device <machine-label> `
  --frames C:\rams\data\kitti\images\val `
  --kitti-labels C:\rams\data\kitti\labels\val `
  --coco-images C:\rams\data\coco\images\val2017 `
  --coco-labels C:\rams\data\coco\labels\val2017
```

### Run Phase 2d and Phase 3 without stopping

The helper runs the corrected transient-burst replay first, then starts the
full KITTI and measured COCO accuracy phase only if Phase 2d succeeds. It
writes a combined manifest in addition to the two normal suite manifests.

```powershell
python scripts\run_phase2d_then_phase3.py --platform windows --device <machine-label> `
  --backend onnx `
  --frames C:\rams\data\kitti\images\val `
  --kitti-labels C:\rams\data\kitti\labels\val `
  --coco-images C:\rams\data\coco\images\val2017 `
  --coco-labels C:\rams\data\coco\labels\val2017 `
  --energy-profile configs\energy_profile_windows.json
```

The full COCO result is valid only when each tier records
`"map_source": "ultralytics_val"` in `results/exp8_accuracy_coco.json`.
The runner fails rather than silently using cached COCO mAP proxies.

## Output required for the paper

- `results/rams_*.csv`: raw per-inference timing, tier, resource telemetry,
  GPU fields when available, and estimated-energy sensitivity values.
- `results/rams_*.json`: grouped latency, tier, and detection summaries with
  confidence intervals.
- `results/rams_*_manifest.json`: ordered frame hashes, seed, timing boundary,
  and paired-block metadata.
- `results/exp8_*`: per-tier KITTI and COCO context.
- `results/exp11_policy_accuracy_*`: policy-level KITTI VRU precision, recall,
  F1, false-negative rate, and non-VRU obstacle metrics. These are the primary
  accuracy results.
- `results/exp12_retention_sensitivity_*`: 0.25 versus 0.40 confidence
  sensitivity, detector-trigger recall, lock coverage, and sustained-VRU
  streak behavior.
- `results/paper_*.json`: commands, inputs, return codes, and device
  context for the complete run.

## Paper wording limits

- In the manuscript, call `predictive` EWMA-smoothed and `adaptive`
  variance-adaptive EWMA.
- Call `safety` VRU-retention and `safety2` two-level VRU-retention. They are
  reactive prioritization policies, not safety guarantees.
- Report block-bootstrap latency intervals and Wilson intervals for binary
  rates. Do not claim a mixed policy is faster than fixed NANO unless paired
  intervals support that statement.
- The default confidence threshold is 0.25. Two-level retention uses normalized
  source-image box area, not a tier-resolution-dependent pixel area.
