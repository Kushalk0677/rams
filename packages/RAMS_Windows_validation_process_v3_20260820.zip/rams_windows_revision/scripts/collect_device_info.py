"""Write a reproducible device and runtime inventory for a RAMS run."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import shutil
import socket
import subprocess
import sys
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from typing import Any

import psutil


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"


def run_command(command: list[str]) -> dict[str, Any]:
    """Run an optional host-information command without making it mandatory."""
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
            timeout=20,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"available": False, "error": str(exc)}
    return {
        "available": completed.returncode == 0,
        "returncode": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def windows_video_controllers() -> dict[str, Any]:
    if platform.system() != "Windows":
        return {"available": False, "reason": "not Windows"}
    command = [
        "powershell",
        "-NoProfile",
        "-Command",
        "Get-CimInstance Win32_VideoController | "
        "Select-Object Name,DriverVersion,AdapterRAM,VideoProcessor,PNPDeviceID | "
        "ConvertTo-Json -Compress",
    ]
    result = run_command(command)
    if not result.get("available") or not result.get("stdout"):
        return result
    try:
        controllers = json.loads(result["stdout"])
    except json.JSONDecodeError as exc:
        result["parse_error"] = str(exc)
        return result
    result["controllers"] = controllers if isinstance(controllers, list) else [controllers]
    result.pop("stdout", None)
    return result


def nvidia_info() -> dict[str, Any]:
    executable = shutil.which("nvidia-smi") or shutil.which("nvidia-smi.exe")
    if not executable:
        return {"available": False, "reason": "nvidia-smi not found"}
    result = run_command(
        [
            executable,
            "--query-gpu=name,driver_version,pstate,memory.total,temperature.gpu,clocks.current.graphics",
            "--format=csv,noheader,nounits",
        ]
    )
    result["executable"] = executable
    if result.get("available"):
        result["gpus"] = [line.strip() for line in result.pop("stdout", "").splitlines() if line.strip()]
    return result


def package_versions() -> dict[str, str | None]:
    names = ["ultralytics", "torch", "torchvision", "onnxruntime", "opencv-python", "numpy", "psutil", "PyYAML"]
    versions: dict[str, str | None] = {}
    for name in names:
        try:
            versions[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            versions[name] = None
    return versions


def onnx_runtime_info() -> dict[str, Any]:
    try:
        import onnxruntime as ort
    except ImportError:
        return {"available": False, "reason": "onnxruntime not installed"}
    return {"available": True, "version": ort.__version__, "providers": ort.get_available_providers()}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def path_inventory(path: Path) -> dict[str, Any]:
    record: dict[str, Any] = {"path": str(path), "exists": path.exists()}
    if path.exists():
        usage = psutil.disk_usage(str(path))
        record["disk"] = {"total_bytes": usage.total, "used_bytes": usage.used, "free_bytes": usage.free}
    return record


def build_report(device: str, data_root: Path | None) -> dict[str, Any]:
    config = ROOT / "configs" / "default.yaml"
    report: dict[str, Any] = {
        "schema_version": 1,
        "collected_at_utc": datetime.now(timezone.utc).isoformat(),
        "device_label": device,
        "hostname": socket.gethostname(),
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
        },
        "python": {"version": sys.version, "executable": sys.executable},
        "cpu": {"physical_cores": psutil.cpu_count(logical=False), "logical_cores": psutil.cpu_count(logical=True)},
        "memory": dict(psutil.virtual_memory()._asdict()),
        "package_versions": package_versions(),
        "onnxruntime": onnx_runtime_info(),
        "windows_video_controllers": windows_video_controllers(),
        "nvidia_smi": nvidia_info(),
        "active_power_scheme": run_command(["powercfg", "/getactivescheme"])
        if platform.system() == "Windows" else {"available": False, "reason": "not Windows"},
        "paths": {"package": path_inventory(ROOT)},
        "config_sha256": sha256(config) if config.is_file() else None,
    }
    if data_root is not None:
        report["paths"]["data_root"] = path_inventory(data_root)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Write RAMS device and runtime inventory JSON")
    parser.add_argument("--device", default=platform.node(), help="stable label stored with this device report")
    parser.add_argument("--data-root", type=Path, default=None, help="optional dataset root to include in disk inventory")
    parser.add_argument("--output", type=Path, default=None, help="optional destination JSON path")
    args = parser.parse_args()

    RESULTS.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output = args.output or RESULTS / f"device_inventory_{stamp}_{args.device}.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(build_report(args.device, args.data_root), indent=2), encoding="utf-8")
    print(f"Device inventory -> {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
