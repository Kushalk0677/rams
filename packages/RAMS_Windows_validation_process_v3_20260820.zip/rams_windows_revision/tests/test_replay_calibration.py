from __future__ import annotations

from pathlib import Path

from scripts.calibrate import apply_thresholds, propose_thresholds


def _profile(
    p10: float,
    p90: float,
    p50: float | None = None,
    p75: float | None = None,
) -> dict:
    return {
        "pressure": {
            "p10": p10,
            "p50": p50 if p50 is not None else (p10 + p90) / 2,
            "p75": p75 if p75 is not None else (p10 + p90) / 2,
            "p90": p90,
        }
    }


def test_proposal_places_normal_replay_in_small_band():
    proposal = propose_thresholds(
        {"idle": _profile(0.42, 0.50), "light": _profile(0.46, 0.56, p50=0.51, p75=0.54), "heavy": _profile(0.70, 0.82, 0.74)},
        minimum_separation=0.03,
    )

    assert proposal["valid"] is True
    assert proposal["lo_thresh"] < 0.42
    assert 0.51 < proposal["hi_thresh"] < 0.74


def test_proposal_refuses_overlapping_pressure_bands():
    proposal = propose_thresholds(
        {"idle": _profile(0.42, 0.55), "light": _profile(0.44, 0.58, p50=0.55, p75=0.56), "heavy": _profile(0.50, 0.65, p50=0.56)},
        minimum_separation=0.03,
    )

    assert proposal["valid"] is False
    assert "does not separate" in proposal["reason"]


def test_proposal_accepts_legacy_thread_tail_overlap_with_separated_medians():
    proposal = propose_thresholds(
        {
            "idle": _profile(0.52, 0.64, p50=0.55, p75=0.59),
            "light": _profile(0.54, 0.74, p50=0.59, p75=0.66),
            "heavy": _profile(0.57, 0.81, p50=0.63, p75=0.69),
        },
        minimum_separation=0.03,
    )

    assert proposal["valid"] is True
    assert proposal["tail_overlap"] > 0.0
    assert proposal["hi_thresh"] == 0.61


def test_apply_updates_all_base_policies_and_adds_adaptive(tmp_path: Path):
    config = tmp_path / "default.yaml"
    backup = tmp_path / "before.yaml"
    config.write_text(
        "policy:\n"
        "  threshold:\n    lo_thresh: 0.6\n    hi_thresh: 0.8\n"
        "  predictive:\n    lo_thresh: 0.6\n    hi_thresh: 0.8\n"
        "  safety:\n    lo_thresh: 0.6\n    hi_thresh: 0.8\n"
        "  safety2:\n    lo_thresh: 0.6\n    hi_thresh: 0.8\n",
        encoding="utf-8",
    )

    apply_thresholds(config, 0.4, 0.7, backup)

    text = config.read_text(encoding="utf-8")
    assert backup.read_text(encoding="utf-8").count("0.6") == 4
    assert "  adaptive:\n    lo_thresh: 0.4\n    hi_thresh: 0.7" in text
    assert text.count("lo_thresh: 0.4") == 5
    assert text.count("hi_thresh: 0.7") == 5
