# RAMS macOS Apple Silicon validation package

Scope: CPU ONNX Runtime validation on Apple Silicon macOS.

Included: current RAMS source, tests, configuration, and operator documentation.

Excluded: datasets, model checkpoints, ONNX exports, TensorRT engines, virtual environments, and result records.
